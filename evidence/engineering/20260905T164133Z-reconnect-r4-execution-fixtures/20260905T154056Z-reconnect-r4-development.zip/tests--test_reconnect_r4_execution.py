import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from tests.reconnect_r4_execution_fixture import make_bundle
from sandbox.run_reconnect_r4 import CORE, GNB, UE


class ExecutionTests(unittest.TestCase):
    def setUp(self):
        for name in ("subprocess.Popen", "socket.socket"):
            guard = patch(name, side_effect=AssertionError("network/process disabled in protocol fixture"))
            guard.start()
            self.addCleanup(guard.stop)

    def bundle(self, case):
        temporary = tempfile.TemporaryDirectory(prefix="safetwin-r4-execution-")
        self.addCleanup(temporary.cleanup)
        output = Path(temporary.name) / "bundle"
        result = make_bundle(output, case)
        return output, result

    def test_complete_protocol_keeps_drop_loss_and_official_rollback_separate(self):
        output, result = self.bundle("complete")
        self.assertTrue(result["protocol_execution_valid"], result)
        self.assertTrue(result["final_service_restored"])
        self.assertFalse(result["network_fix_validated"])
        trials = [json.loads(p.read_bytes()) for p in sorted(output.glob("trial-*.json"))]
        self.assertEqual([sum(s["result"]["ping"]["packets_received"] for s in t["post"]) for t in trials], [15, 14, 14, 15])

    def test_negative_prefixes_stop_and_attempt_official_restoration(self):
        for case in ("bad-baseline", "ineligible-source", "incomplete-trace", "failed-switch", "timeout", "missing-fresh-pdu"):
            with self.subTest(case=case):
                output, result = self.bundle(case)
                self.assertFalse(result["protocol_execution_valid"], result)
                self.assertTrue(result["official_image_restored"] and result["final_service_restored"], result)
                self.assertLess(result["attempted_assignments"], 4)

    def test_final_rollback_failures_are_not_success_and_each_reset_is_attempted(self):
        for case in ("failed-final-switch", "failed-cleanup", "failed-reset", "failed-official-service"):
            with self.subTest(case=case):
                output, result = self.bundle(case)
                self.assertFalse(result["protocol_execution_valid"] or result["final_service_restored"], result)
                rows = [json.loads(line) for line in (output / "commands.jsonl").read_text().splitlines()]
                resets = [r["argv"][2] for r in rows if r["unit_id"] == "final-rollback" and r["argv"][:2] == ["docker", "restart"]]
                self.assertEqual(resets, [CORE, GNB, UE])


if __name__ == "__main__":
    unittest.main()
