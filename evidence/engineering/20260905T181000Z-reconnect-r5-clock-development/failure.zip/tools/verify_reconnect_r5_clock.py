"""R5 software-gate evidence capture. No network execution or clock setting."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
SOURCES = ["sandbox/reconnect_r5_clock.py", "tools/audit_reconnect_r5_clock.py", "tests/test_reconnect_r5_clock.py",
           "tools/verify_reconnect_r5_clock.py", "docs/RECONNECT_R5_CLOCK.md"]


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")


def directory(suffix):
    output = ROOT / "evidence/engineering" / (datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ") + suffix)
    output.mkdir(exist_ok=False)
    return output


def development():
    output = directory("-reconnect-r5-clock-development")
    argv = [sys.executable, "-m", "pytest", "tests/test_reconnect_r5_clock.py::test_strict_json_rejects_ambiguity", "-q", "--tb=short", "-rN"]
    started = datetime.now(timezone.utc).isoformat()
    child = subprocess.run(argv, cwd=ROOT, capture_output=True, timeout=35, creationflags=subprocess.CREATE_NO_WINDOW)
    entries = {n: (ROOT / n).read_bytes() for n in SOURCES if (ROOT / n).is_file()}
    entries.update({"capture/stdout.log": child.stdout, "capture/stderr.log": child.stderr})
    with zipfile.ZipFile(output / "failure.zip", "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for name, raw in entries.items():
            archive.writestr(name, raw)
    with zipfile.ZipFile(output / "failure.zip") as archive:
        assert all(archive.read(n) == raw for n, raw in entries.items())
    save(output / "failure.json", dict(argv=argv, started_at=started, completed_at=datetime.now(timezone.utc).isoformat(),
                                       exit_code=child.returncode, member_sha256={n: sha(raw) for n, raw in entries.items()},
                                       purpose="pre-correction-test-harness-failure-not-network-trial", evidence_label="fixture",
                                       source_snapshot_before_correction=True, actual_docker_commands=0))
    save(output / "manifest.json", {"captured_file_sha256": {p.name: sha(p.read_bytes()) for p in output.iterdir() if p.is_file()}})
    print(re.sub(r" {100,}", "<oversized-param-id>", child.stdout.decode("utf-8", "replace"))[-6000:])
    print(json.dumps(dict(output=str(output), exit_code=child.returncode, captured_stdout_bytes=len(child.stdout))))


if __name__ == "__main__":
    if sys.argv[1:] == ["--capture-development"]:
        development()
    else:
        raise SystemExit("software gate is not frozen yet")
