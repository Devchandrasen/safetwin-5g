"""Whole-protocol fixtures are never promoted to measured network evidence."""
from tests.reconnect_r5_execution_fixture import capture_case
from tools.audit_reconnect_r5_execution import audit_path


def test_complete_four_trial_fixture(tmp_path):
    b = capture_case(tmp_path/"complete")
    r = b["result"]
    assert r["protocol_execution_valid"], r["errors"] or r["trials"]
    assert len(r["trials"]) == 4
    assert [t["recovery_15_of_15"] for t in r["trials"]] == [True, False, False, True]
    assert r["rollback"]["service_restored"]
    assert not r["network_fix_validated"] and not r["TNSM_ready"]
    audit = audit_path(tmp_path/"complete")
    assert audit["protocol_execution_valid"]
    assert audit["drop_recovery_15_of_15"] == [False, False]
