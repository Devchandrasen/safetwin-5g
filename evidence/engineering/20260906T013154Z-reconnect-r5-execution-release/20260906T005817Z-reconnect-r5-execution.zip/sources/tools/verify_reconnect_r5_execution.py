"""Software-only full integration verification; preserve pre-test sources.

Never invokes a network, clock-native or power verifier. Generated failed
directories are immutable evidence, not retries under the same pathname.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
SOURCES = ["sandbox/run_reconnect_r5.py", "sandbox/reconnect_r5_scope.py",
           "tools/reconnect_r5_global_budget_audit.py", "tools/reconnect_r5_global_collection_audit.py",
           "tools/reconnect_r5_global_host_audit.py", "tools/audit_reconnect_r5_execution.py",
           "tools/verify_reconnect_r5_execution.py", "tests/reconnect_r5_execution_fixture.py",
           "tests/test_reconnect_r5_execution.py", "docs/RECONNECT_R5_EXECUTION.md"]


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, allow_nan=False)+"\n", encoding="utf-8")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--full", action="store_true")
    args = parser.parse_args()
    output = ROOT/"evidence/verification"/(datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")+"-reconnect-r5-execution")
    output.mkdir(exist_ok=False)
    hashes = {}
    for name in SOURCES:
        path = ROOT/name
        if path.is_file():
            raw = path.read_bytes()
            target = output/"sources"/name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(raw)
            hashes[name] = hashlib.sha256(raw).hexdigest()
    save(output/"source-before.json", hashes)
    argv = [sys.executable, "-m", "pytest", "-q", "tests" if args.full else "tests/test_reconnect_r5_execution.py",
            "-k", "not native", "--basetemp", str(output/"pytest-temp")]
    # File-backed output preserves failure/traceback without truncation.
    with (output/"pytest.txt").open("wb") as stream:
        completed = subprocess.run(argv, cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT, check=False)
    report = dict(evidence_label="fixture", command=argv, pytest_exit=completed.returncode,
                  network_execution_authorized=False, network_fix_validated=False, TNSM_ready=False,
                  source_sha256=hashes, source_unchanged=all(hashlib.sha256((ROOT/n).read_bytes()).hexdigest() == h for n, h in hashes.items()))
    save(output/"report.json", report)
    save(output/"manifest.json", {"sha256": {p.relative_to(output).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
                                          for p in sorted(output.rglob("*")) if p.is_file()}})
    print(str(output), flush=True)
    print((output/"pytest.txt").read_text(errors="replace")[-22000:], flush=True)
    raise SystemExit(completed.returncode)


if __name__ == "__main__":
    main()
